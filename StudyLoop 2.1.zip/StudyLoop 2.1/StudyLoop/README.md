# StudyLoop (Week 9 vertical slice)

## Setup
- Python 3.11+ recommended
- (Optional) Create venv:  python -m venv .venv
- Activate (CMD):         .\.venv\Scripts\activate
  (PowerShell: Set-ExecutionPolicy -Scope CurrentUser RemoteSigned; then .\.venv\Scripts\Activate)
- Install deps:           pip install -r requirements.txt

## Run
python app.py
→ http://127.0.0.1:5000

## Feature slice
- Create Post (title, course, tags normalized, prompt)
- Filter feed by text/course/tag; sort by newest/replies/Q-score
- View Post, upload video reply (MP4/WebM/OGG/OGV), transcript required
- Rate replies (Clear/Correct/Concise) and report

## Files
- Database: studyloop.db (auto-created)
- Uploads:  /uploads (auto-created)
